import os
import time
import colorama
from colorama import Fore
colorama.init()

color_1 = Fore.BLUE
color_2 = Fore.RED
color_3 = Fore.LIGHTGREEN_EX
color_4 = Fore.LIGHTRED_EX

Main_logo = f"""
{color_1} ▄▀▀▄▀▀▀▄  ▄▀▀▀▀▄      ▄▀▀█▄   ▄▀▀▀█▀▀▄  ▄▀▀█▀{color_2}▄    ▄▀▀▄ ▀▄  ▄▀▀█▀▄   ▄▀▀▄ ▄▀▀▄  ▄▀▀▄ ▄▀▄ 
{color_1}█   █   █ █    █      ▐ ▄▀ ▀▄ █    █  ▐ █   █ {color_2} █  █  █ █ █ █   █  █ █   █    █ █  █ ▀  █ 
{color_1}▐  █▀▀▀▀  ▐    █        █▄▄▄█ ▐   █     ▐   █ {color_2} ▐  ▐  █  ▀█ ▐   █  ▐ ▐  █    █  ▐  █    █ 
{color_1}   █          █        ▄▀   █    █          █ {color_2}      █   █      █      █    █     █    █  
{color_1} ▄▀         ▄▀▄▄▄▄▄▄▀ █   ▄▀   ▄▀        ▄▀▀▀▀{color_2}▀▄  ▄▀   █    ▄▀▀▀▀▀▄    ▀▄▄▄▄▀  ▄▀   ▄▀   
{color_1}█           █         ▐   ▐   █         █     {color_2}  █ █    ▐   █       █           █    █    
{color_1}▐           ▐                 ▐         ▐      {color_2} ▐ ▐        ▐       ▐           ▐    ▐  
                                                    {color_3}Take away the first amendment
                                                    {color_3}C0D3D by Steezy#6272
"""

Main_Hub = f"""
{color_1}[1] pinger
{color_1}[2] ip lookup
{color_2}[3] ddos
{color_2}[4] LucidREaps
{color_4}[5] Exit
"""

def Main():
    os.system('cls')
    print(Main_logo)
    print(Main_Hub)
    choice = input ('@> ')
    if choice == '1':
        os.startfile('Kanagawa.bat')
    if choice == '2':
        os.startfile('iplookup.exe')
    if choice == '3':
        os.startfile('cc.exe')
    if choice == '4':
        os.startfile('lucidreaps.exe')
    if choice == '5':
        print('exiting!')
        time.sleep(3)
        exit(0)
    else:
        print('invalid input!')
        time.sleep(2)
        Main()

Main()